export enum InputType {
	TEXT = 'text',
	EMAIL = 'email',
	PASSWORD = 'password',
}
