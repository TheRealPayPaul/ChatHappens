export enum Sender {
	Self,
	Other,
}
