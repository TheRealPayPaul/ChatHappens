import { ErrorMessageDirective } from './error-message.directive';

describe('ErrorMessageDirective', () => {
	it('should create an instance', () => {
		expect(true).toBeTrue();
	});
});
